var props = [{
        nombre: "Escala",
        propiedad: "transform",
        valores: ["scale(.5)", "scale(2)", "scale(2,3)", "scale(5)"]
    }, {
        nombre: "Color",
        propiedad: "color",
        valores: ["red", "green", "#00f", "rgba(0,0,0,0.5)"]
    }, {
        nombre: "Rotación",
        propiedad: "transform",
        valores: ["rotate(45deg)", "rotate(90deg)", "rotate(270deg)", "rotate(0deg)"]
    }, {
        nombre: "Animation",
        propiedad: "animation",
        valores: ["color 5s linear infinite", "girar 4s linear infinite", "saltar 1s ease infinite"]
    }, {
        nombre: "Color de fondo",
        propiedad: "background",
        valores: ["#f00", "#eee", "black", "green"]
    }, {
        nombre: "Border Radius",
        propiedad: "border-radius",
        valores: ["0", "50%", "10px", "100%"]
    }, {
        nombre: "Outline",
        propiedad: "outline",
        valores: ["2px dotted blue", "5px dashed red", "5px double #faf", "10px ridge #eaa"]
    }

];
function cargarPropiedades() {
    var sel = document.getElementById("selProp");
    for (var i = 0; i < props.length; i++) {
        var o = document.createElement("option");
        o.value = props[i].propiedad;
        o.innerHTML = props[i].nombre;
        sel.appendChild(o);
    }
    mostrarProp();
}
function cajaSelec() {
    var sel = document.getElementById("selCaja").selectedOptions[0];
    var val = "caja1";
    if (sel !== undefined) {
        if (sel.value !== undefined)
            val = sel.value;
    }
    return document.getElementById(val);
}
function mostrarProp() {
    var ele = cajaSelec();
    var sel = document.getElementById("selProp").selectedOptions[0];
    var selV = document.getElementById("selValor");
    selV.innerHTML = "";
    if (sel !== undefined) {
        for (var i = 0; i < props.length; i++) {
            if (props[i].nombre === sel.innerHTML) {
                for (var j = -1; j < props[i].valores.length; j++) {
                    if (j === -1) {
                        var o = document.createElement("option");
                        o.value = "";
                        selV.appendChild(o);
                    } else {
                        var o = document.createElement("option");
                        o.value = props[i].valores[j];
                        o.innerHTML = props[i].valores[j];
                        selV.appendChild(o);
                    }
                }
            }
        }
    }
}
function aplicarEstilo() {
    var ele = cajaSelec();
    var sel = document.getElementById("selProp").selectedOptions[0];
    var selV = document.getElementById("selValor").selectedOptions[0];
    if (sel !== undefined && selV !== undefined) {
        var s = selV.value;
//       if(sel.value==="animation"&&ele.style.getPropertyValue(sel.value)!==""){
//         s=s+","+ele.style.getPropertyValue(sel.value);
//        }
        ele.style.setProperty(sel.value, s);
    }
}