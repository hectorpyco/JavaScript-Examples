function cargar() {
	con = document.getElementById("contenedor");
	spr = document.getElementById("propiedad");
	spr.innerHTML=" ";
	for (i in con.style) {
		if(i=="transform" || i=="color" || i=="animation"){
			spr.insertAdjacentHTML("beforeend", "<option name='" + i + "' value='" + con[i] + "'>" + i + "</option>");
		}
	}
	sel = document.getElementById("elemento");
	sel.innerHTML=" ";
	for (i=0;i<con.children.length;i++) {
		sel.insertAdjacentHTML("beforeend", "<option name='" + i + "' value='" + con.children[i].localName+ "'>" + con.children[i].localName + " " + (i+1)  +"</option>");
	}
	cambiar();
	
}
function aplicar() {
	con = document.getElementById("contenedor");
	sel = document.getElementById("elemento");
	spr = document.getElementById("propiedad");
	val = document.getElementById("valor");
	i = sel.selectedIndex;
	j = spr.options[spr.selectedIndex].text;
	ele = con.children[i].style[j]=val.options[val.selectedIndex].value;
}
function cambiar(){
	spr = document.getElementById("propiedad");
	j = spr.options[spr.selectedIndex].text;
	val = document.getElementById("valor");
	val.innerHTML=" ";
	switch(j){
		case "color":
			val.innerHTML="<option value='blue'>Azul</option><option value='red'>Rojo</option>";
			break;
		case "transform":
			val.innerHTML="<option value='scale(4)'>Scale(4)</option><option value='rotate(40deg)'>Rotate(40deg)</option>";
			break;
		case "animation":
			val.innerHTML="<option value='ani1 4s infinite'>Animacion 1</option><option value='ani2 4s infinite'>Animacion 2</option>";
			break;
	}
	
}
